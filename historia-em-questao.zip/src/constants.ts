import { ExamBoard, HistoriographyItem } from './types';

export const EXAM_BOARDS: ExamBoard[] = [
  {
    id: 'ENEM',
    nome: 'ENEM',
    estilo: 'Contextualização e Cidadania. Questões baseadas em competências e habilidades. Foco em problemas sociais contemporâneos ligados ao passado, análise de gráficos/tabelas e interdisciplinaridade. Padrão: 5 alternativas objetivas.',
    pontuacao: 'TRI (Teoria de Resposta al Item). Nota varia conforme coerência pedagógica.',
    analise_detalhada: {
      estrutura: '45 questões de Ciências Humanas, sendo aproximadamente 15 de História. Questões baseadas em textos de apoio, imagens e gráficos.',
      temas_frequentes: [
        { tema: 'Brasil Colônia', porcentagem: 25 },
        { tema: 'Brasil Império', porcentagem: 20 },
        { tema: 'Era Vargas', porcentagem: 15 },
        { tema: 'Idade Contemporânea', porcentagem: 15 },
        { tema: 'Patrimônio e Memória', porcentagem: 10 }
      ],
      dicas_estudo: [
        'Foque em competências e habilidades, não apenas em datas.',
        'Pratique a interpretação de textos e imagens.',
        'Relacione o passado com problemas sociais atuais.'
      ],
      ultima_atualizacao: '2024 (Pós-ENEM 2023)'
    }
  },
  {
    id: 'FUVEST',
    nome: 'FUVEST (USP)',
    estilo: 'Densidade Conceitual. Exigência de cronologia precisa e vocabulário técnico historiográfico. Foco em processos estruturais (economia, política e sociedade). Alternativas sutis, com pegadinhas de memória.',
    pontuacao: '1 ponto por questão correta na 1ª fase. Discursivas valem peso maior.',
    analise_detalhada: {
      estrutura: '1ª Fase: Questões objetivas dentro de Conhecimentos Gerais. 2ª Fase: Questões discursivas específicas de História.',
      temas_frequentes: [
        { tema: 'História Moderna', porcentagem: 22 },
        { tema: 'Brasil Colônia', porcentagem: 20 },
        { tema: 'Mundo Contemporâneo', porcentagem: 18 },
        { tema: 'Brasil República', porcentagem: 15 },
        { tema: 'Antiguidade Clássica', porcentagem: 10 }
      ],
      dicas_estudo: [
        'Domine a cronologia e os conceitos técnicos.',
        'Estude os processos econômicos e sociais de longo prazo.',
        'Prepare-se para questões que exigem leitura densa.'
      ],
      ultima_atualizacao: '2024 (Pós-FUVEST 2024)'
    }
  },
  {
    id: 'UNICAMP',
    nome: 'UNICAMP',
    estilo: 'Crítica e Historiografia. Abordagem social, cultural e diversificada. OBRIGATÓRIO: uso de imagens (pinturas, charges) ou trechos de documentos primários/fontes históricas. Questões que dialogam com a Nova História Cultural.',
    pontuacao: '1 ponto por questão correta na 1ª fase. Discursivas valem peso maior.'
  },
  {
    id: 'UNESP',
    nome: 'UNESP (Vunesp)',
    estilo: 'Letramento Histórico. Uso OBRIGATÓRIO de texto de apoio longo (citação de historiador ou documento). A pergunta exige que o aluno relacione diretamente o texto com o contexto histórico mais amplo.',
    pontuacao: '1 ponto por questão correta na 1ª fase. Discursivas valem peso maior.'
  },
  {
    id: 'UFPR',
    nome: 'UFPR',
    estilo: 'Síntese e Objetividade. Questões diretas, com 4 alternativas apenas. Foco em fatos consolidados da historiografia, sem floreios.',
    pontuacao: '1 ponto por questão correta.'
  },
  {
    id: 'UFRGS',
    nome: 'UFRGS',
    estilo: 'Equilíbrio e Previsibilidade. Questões claras, com distribuição simétrica de conteúdo. Foco em história do Brasil e Rio Grande do Sul. Evita anacronismos gritantes.',
    pontuacao: '1 ponto por questão correta.'
  },
  {
    id: 'UFSC',
    nome: 'UFSC',
    estilo: 'Lógica de Somatório. A questão deve ser formulada para o sistema de proposições múltiplas. O gabarito final é a soma dos números das alternativas corretas (Ex: 01+04+16 = 21).',
    pontuacao: 'Somatório. Proposições corretas somam; erros ou omissões não pontuam.'
  },
  {
    id: 'UERJ',
    nome: 'UERJ',
    estilo: 'Interdisciplinaridade Dirigida. A questão pode conectar a História com a Literatura de leitura obrigatória do vestibular da UERJ ou com temas de atualidades do Rio de Janeiro.',
    pontuacao: '1 ponto por questão correta.'
  },
  {
    id: 'UnB',
    nome: 'UnB (Cebraspe)',
    estilo: 'Julgamento Certo/Errado. O texto de apoio deve ser um item único seguido de assertivas para o candidato julgar. Lógica de penalização: Uma errada anula uma certa.',
    pontuacao: 'Certo/Errado. Acerto = +1; Erro = -1; Em branco = 0.'
  },
  {
    id: 'MACKENZIE',
    nome: 'Mackenzie / PUC-SP',
    estilo: 'Tradicional e Conceitual. Equilíbrio entre a decoreba de nomenclatura (Renascimento, Reforma) e a interpretação de texto. Alternativas muito bem escritas, sem absurdos para eliminação fácil.',
    pontuacao: '1 ponto por questão correta.'
  },
  {
    id: 'ITA',
    nome: 'ITA / IME',
    estilo: 'Objetividade e Raciocínio Lógico. Questões curtas, sem textos enormes, que exigem um conhecimento pontual de datas e definições técnicas.',
    pontuacao: '1 ponto por questão correta.'
  },
  {
    id: 'SAEB',
    nome: 'Saeb',
    estilo: 'Foco em Descritores. Avaliação de competências de leitura e interpretação de textos históricos. Questões objetivas que medem níveis de proficiência.',
    pontuacao: 'Escala de Proficiência Saeb.'
  },
  {
    id: 'SARESP',
    nome: 'Saresp',
    estilo: 'Currículo Paulista. Questões baseadas nas habilidades e competências do currículo do estado de São Paulo, com foco em documentos e textos de apoio.',
    pontuacao: 'Escala de Proficiência Saresp.'
  },
  {
    id: 'PROVA_BRASIL',
    nome: 'Prova Brasil',
    estilo: 'Habilidades Básicas. Focada no Ensino Fundamental, utiliza questões contextualizadas para verificar o domínio de descritores de aprendizagem.',
    pontuacao: 'Escala de Proficiência Saeb.'
  },
  {
    id: 'FGV',
    nome: 'FGV',
    estilo: 'Alto nível de interpretação. Foco em História Contemporânea, Economia e Política. Uso frequente de documentos, charges e textos acadêmicos. Exige análise crítica e visão sistêmica dos processos históricos.',
    pontuacao: '1 ponto por questão correta. Discursivas com critérios rigorosos de argumentação.'
  },
  {
    id: 'ESPM',
    nome: 'ESPM',
    estilo: 'Foco em Cultura, Comunicação e História Contemporânea. Questões contextualizadas que relacionam o passado com a propaganda, o consumo e as transformações sociais. Estilo direto mas que exige leitura atenta.',
    pontuacao: '1 ponto por questão correta.'
  }
];

export const HISTORIOGRAPHY: HistoriographyItem[] = [
  {
    periodo: 'História Antiga',
    leituras: [
      { autor: 'FUNARI, Pedro Paulo', titulo: 'Antiguidade Clássica: A História e a Cultura a partir dos Documentos' },
      { autor: 'CARDOSO, Ciro Flamarion', titulo: 'Sete Olhares sobre a Antiguidade' }
    ]
  },
  {
    periodo: 'História Medieval',
    leituras: [
      { autor: 'LE GOFF, Jacques', titulo: 'Em Busca da Idade Média' },
      { autor: 'DUBY, Georges', titulo: 'As Três Ordens ou o Imaginário do Feudalismo' }
    ]
  },
  {
    periodo: 'História Moderna',
    leituras: [
      { autor: 'ELIAS, Norbert', titulo: 'O Processo Civilizador' },
      { autor: 'DARNTON, Robert', titulo: 'O Grande Massacre de Gatos' }
    ]
  },
  {
    periodo: 'História do Brasil Colônia/Império',
    leituras: [
      { autor: 'HOLANDA, Sérgio Buarque de', titulo: 'Raízes do Brasil' },
      { autor: 'ALENCASTRO, Luiz Felipe de', titulo: 'O Trato dos Viventes' }
    ]
  },
  {
    periodo: 'História do Brasil República',
    leituras: [
      { autor: 'CARVALHO, José Murilo de', titulo: 'Cidadania no Brasil: O Longo Caminho' },
      { autor: 'SCHWARCZ, Lilia M. & STARLING, Heloisa M.', titulo: 'Brasil: Uma Biografia' }
    ]
  },
  {
    periodo: 'História Contemporânea',
    leituras: [
      { autor: 'HOBSBAWM, Eric', titulo: 'Era dos Extremos: O Breve Século XX' },
      { autor: 'JUDT, Tony', titulo: 'Pós-Guerra: História da Europa desde 1945' }
    ]
  }
];
