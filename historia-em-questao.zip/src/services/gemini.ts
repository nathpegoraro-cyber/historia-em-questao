import { GoogleGenAI, Type } from "@google/genai";
import { Question } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

const SYSTEM_INSTRUCTION = `Você é um motor avançado de geração de avaliações acadêmicas, especializado em História para vestibulares nacionais brasileiros.

### 🧠 IDENTIDADES DAS BANCAS
Ao gerar questões inéditas, incorpore a personalidade da banca:
- ENEM: Contextualização, Cidadania, competências, 5 alternativas.
- FUVEST: Densidade Conceitual, cronologia precisa, vocabulário técnico.
- UNICAMP: Crítica, Historiografia, fontes primárias/documentos.
- UNESP: Letramento Histórico, texto de apoio longo.
- UFPR: Síntese, Objetividade, 4 alternativas.
- UFRGS: Equilíbrio, Previsibilidade.
- UFSC: Lógica de Somatório (proposições 01, 02, 04, 08, 16...).
- UERJ: Interdisciplinaridade (Literatura/Atualidades RJ).
- UnB: Julgamento Certo/Errado.
- Mackenzie/PUC-SP: Tradicional, Conceitual.
- ITA/IME: Objetividade, Raciocínio Lógico.
- FGV: Alto nível de interpretação, Foco em Economia/Política, documentos/charges.
- ESPM: Cultura, Comunicação, História Contemporânea, relação com consumo/mídia.
- Saeb/Prova Brasil: Foco em Descritores, competências de leitura, proficiência.
- Saresp: Currículo Paulista, habilidades específicas do estado de SP.

### 📚 CRITÉRIOS DE FONTES
Use historiadores renomados (Boris Fausto, Lilia Schwarcz, Hobsbawm, etc.).
Citação obrigatória em ABNT NBR 6023.

### MODOS
1. Modo Geração: Crie questões inéditas.
2. Modo Recuperação: Recupere questões REAIS de vestibulares passados.`;

const questionSchema = {
  type: Type.OBJECT,
  properties: {
    banca_simulada: { type: Type.STRING },
    vestibular_original: { type: Type.STRING },
    texto_apoio: { type: Type.STRING },
    enunciado: { type: Type.STRING },
    alternativas: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Lista de alternativas para questões objetivas. Deixe vazio para discursivas."
    },
    gabarito: { type: Type.STRING, description: "Resposta correta ou padrão de resposta esperado." },
    comentario: { type: Type.STRING },
    tipo: { type: Type.STRING, enum: ["objetiva", "discursiva"] },
    dificuldade: { type: Type.STRING, enum: ["fácil", "médio", "difícil"] }
  },
  required: ["texto_apoio", "enunciado", "alternativas", "gabarito", "comentario", "tipo", "dificuldade"]
};

export async function generateSimulado(
  assunto: string, 
  bancas: string[], 
  quantidade: number = 10,
  dificuldades: string[] = ["médio"],
  tipo: string = "mista"
): Promise<Question[]> {
  const bancasStr = bancas.includes('Mista') ? 'principais bancas nacionais' : bancas.join(', ');
  const dificuldadesStr = dificuldades.join(', ');
  const prompt = `Gere um simulado de ${quantidade} questões inéditas sobre o assunto "${assunto}".
  Bancas/Instituições alvo: ${bancasStr}.
  Dificuldades desejadas: ${dificuldadesStr} (distribua as questões entre esses níveis).
  Tipo de questões: ${tipo} (Se "discursiva", baseie-se em estilos de 2ª fase).`;
  
  const response = await ai.models.generateContent({
    model: "gemini-3.1-pro-preview",
    contents: prompt,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: questionSchema
      }
    }
  });

  return JSON.parse(response.text || "[]");
}

export async function searchQuestions(filtros: {
  tema?: string,
  instituicao?: string,
  ano?: string,
  dificuldade?: string,
  tipo?: string
}): Promise<Question[]> {
  const prompt = `Recupere questões REAIS de vestibulares passados com os seguintes filtros:
  Tema: ${filtros.tema || "Qualquer"}
  Instituição: ${filtros.instituicao || "Qualquer"}
  Ano: ${filtros.ano || "Qualquer"}
  Dificuldade: ${filtros.dificuldade || "Qualquer"}
  Tipo: ${filtros.tipo || "Qualquer"}
  
  Retorne um array de até 5 questões que melhor correspondam aos critérios.`;
  
  const response = await ai.models.generateContent({
    model: "gemini-3.1-pro-preview",
    contents: prompt,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: questionSchema
      }
    }
  });

  return JSON.parse(response.text || "[]");
}
