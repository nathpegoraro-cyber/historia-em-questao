export interface Question {
  banca_simulada?: string;
  vestibular_original?: string;
  texto_apoio: string;
  enunciado: string;
  alternativas: string[];
  gabarito: string;
  comentario: string;
  tipo: 'objetiva' | 'discursiva';
  dificuldade: 'fácil' | 'médio' | 'difícil';
}

export type TabType = 'bancas' | 'historiografia' | 'simulados' | 'questoes_passadas';

export interface ExamBoard {
  id: string;
  nome: string;
  estilo: string;
  pontuacao: string;
  analise_detalhada?: {
    estrutura: string;
    temas_frequentes: { tema: string; porcentagem: number }[];
    dicas_estudo: string[];
    ultima_atualizacao: string;
  };
}

export interface HistoriographyItem {
  periodo: string;
  leituras: {
    autor: string;
    titulo: string;
  }[];
}
