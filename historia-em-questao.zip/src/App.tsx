import React, { useState } from 'react';
import { TabType } from './types';
import BancasInfo from './components/BancasInfo';
import HistoriographyInfo from './components/HistoriographyInfo';
import SimuladoGenerator from './components/SimuladoGenerator';
import QuestionSearch from './components/QuestionSearch';
import { motion, AnimatePresence } from 'motion/react';
import { ScrollText, Library, Sparkles, History, GraduationCap } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('simulados');

  const tabs = [
    { id: 'simulados', label: 'Simulados', icon: Sparkles },
    { id: 'questoes_passadas', label: 'Vestibulares Passados', icon: History },
    { id: 'bancas', label: 'Bancas', icon: ScrollText },
    { id: 'historiografia', label: 'Historiografia', icon: Library },
  ];

  return (
    <div className="min-h-screen bg-paper flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-sepia/10 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-olive rounded-xl flex items-center justify-center text-white">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-serif font-bold tracking-tight text-ink">História em Questão</h1>
              <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-sepia/40">Motor de Avaliação Acadêmica</p>
            </div>
          </div>

          <nav className="hidden md:flex items-center gap-1 bg-paper p-1 rounded-2xl border border-sepia/5">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabType)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${
                  activeTab === tab.id 
                    ? 'bg-white text-olive shadow-sm' 
                    : 'text-sepia/50 hover:text-sepia hover:bg-white/50'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </nav>
        </div>
      </header>

      {/* Mobile Nav */}
      <div className="md:hidden bg-white border-b border-sepia/10 px-4 py-2 flex gap-2 overflow-x-auto no-scrollbar">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as TabType)}
            className={`flex-shrink-0 flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-medium transition-all ${
              activeTab === tab.id 
                ? 'bg-olive text-white shadow-sm' 
                : 'bg-paper text-sepia/50'
            }`}
          >
            <tab.icon className="w-3 h-3" />
            {tab.label}
          </button>
        ))}
      </div>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-6 py-12">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {activeTab === 'simulados' && <SimuladoGenerator />}
            {activeTab === 'questoes_passadas' && <QuestionSearch />}
            {activeTab === 'bancas' && <BancasInfo />}
            {activeTab === 'historiografia' && <HistoriographyInfo />}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-sepia/10 py-12">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="text-center md:text-left">
            <h2 className="text-lg font-serif font-bold text-sepia">História em Questão</h2>
            <p className="text-sm text-sepia/40">© 2026 — Rigor Acadêmico e Excelência Historiográfica</p>
          </div>
          <div className="flex gap-8 text-xs font-bold uppercase tracking-widest text-sepia/40">
            <span className="hover:text-olive cursor-pointer transition-colors">Termos</span>
            <span className="hover:text-olive cursor-pointer transition-colors">Privacidade</span>
            <span className="hover:text-olive cursor-pointer transition-colors">Contato</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
