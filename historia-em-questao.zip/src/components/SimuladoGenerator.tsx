import React, { useState } from 'react';
import { generateSimulado } from '../services/gemini';
import { Question } from '../types';
import { EXAM_BOARDS } from '../constants';
import QuestionCard from './QuestionCard';
import { Loader2, Sparkles, BookOpen, Check, History } from 'lucide-react';

export default function SimuladoGenerator() {
  const [assunto, setAssunto] = useState('');
  const [bancasSelecionadas, setBancasSelecionadas] = useState<string[]>(['Mista']);
  const [quantidade, setQuantidade] = useState(10);
  const [dificuldades, setDificuldades] = useState<string[]>(['médio']);
  const [tipo, setTipo] = useState('mista');
  const [loading, setLoading] = useState(false);
  const [questions, setQuestions] = useState<Question[]>([]);

  const toggleBanca = (id: string) => {
    if (id === 'Mista') {
      setBancasSelecionadas(['Mista']);
      return;
    }
    
    setBancasSelecionadas(prev => {
      const semMista = prev.filter(b => b !== 'Mista');
      if (semMista.includes(id)) {
        const novo = semMista.filter(b => b !== id);
        return novo.length === 0 ? ['Mista'] : novo;
      } else {
        return [...semMista, id];
      }
    });
  };

  const toggleDificuldade = (nivel: string) => {
    setDificuldades(prev => {
      if (prev.includes(nivel)) {
        if (prev.length === 1) return prev; // Mantém pelo menos uma
        return prev.filter(d => d !== nivel);
      } else {
        return [...prev, nivel];
      }
    });
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!assunto) return;
    
    setLoading(true);
    try {
      const result = await generateSimulado(assunto, bancasSelecionadas, quantidade, dificuldades, tipo);
      setQuestions(result);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white border border-sepia/10 rounded-3xl p-8 shadow-sm mb-12">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-olive/10 rounded-2xl text-olive">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-2xl font-serif font-bold">Gerar Simulado Inédito</h2>
            <p className="text-sepia/60 text-sm">Crie questões exclusivas com base no estilo das bancas.</p>
          </div>
        </div>

        <form onSubmit={handleGenerate} className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Seção 1: Configurações Básicas */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-1">
                <BookOpen className="w-4 h-4 text-olive" />
                <label className="text-xs font-bold uppercase tracking-wider text-sepia/70">Configurações Básicas</label>
              </div>
              
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-sepia/50 uppercase ml-1">Assunto Histórico</label>
                  <input 
                    type="text" 
                    value={assunto}
                    onChange={(e) => setAssunto(e.target.value)}
                    placeholder="Ex: Brasil Colônia..."
                    className="w-full p-4 bg-paper border border-sepia/10 rounded-2xl focus:outline-none focus:ring-2 focus:ring-olive/20 transition-all"
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-sepia/50 uppercase ml-1">Quantidade de Questões</label>
                  <input 
                    type="number" 
                    min="1"
                    max="30"
                    value={quantidade}
                    onChange={(e) => setQuantidade(Math.max(1, Math.min(30, Number(e.target.value))))}
                    className="w-full p-4 bg-paper border border-sepia/10 rounded-2xl focus:outline-none focus:ring-2 focus:ring-olive/20 transition-all"
                  />
                </div>
              </div>
            </div>

            {/* Seção 2: Critérios de Avaliação */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-1">
                <Sparkles className="w-4 h-4 text-olive" />
                <label className="text-xs font-bold uppercase tracking-wider text-sepia/70">Critérios de Avaliação</label>
              </div>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-sepia/50 uppercase ml-1">Dificuldade</label>
                  <div className="flex gap-2">
                    {['fácil', 'médio', 'difícil'].map(nivel => (
                      <button
                        key={nivel}
                        type="button"
                        onClick={() => toggleDificuldade(nivel)}
                        className={`flex-1 py-3 rounded-xl border text-xs font-bold uppercase transition-all ${
                          dificuldades.includes(nivel)
                          ? 'bg-olive text-white border-olive shadow-sm'
                          : 'bg-paper text-sepia border-sepia/10 hover:border-olive/30'
                        }`}
                      >
                        {nivel}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-sepia/50 uppercase ml-1">Formato das Questões</label>
                  <div className="flex gap-2">
                    {[
                      { id: 'mista', label: 'Mista' },
                      { id: 'objetiva', label: 'Objetiva' },
                      { id: 'discursiva', label: '2ª Fase' }
                    ].map(f => (
                      <button
                        key={f.id}
                        type="button"
                        onClick={() => setTipo(f.id)}
                        className={`flex-1 py-3 rounded-xl border text-xs font-bold uppercase transition-all ${
                          tipo === f.id
                          ? 'bg-olive text-white border-olive shadow-sm'
                          : 'bg-paper text-sepia border-sepia/10 hover:border-olive/30'
                        }`}
                      >
                        {f.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Seção 3: Instituições */}
          <div className="space-y-4 pt-4 border-t border-sepia/5">
            <div className="flex items-center gap-2 mb-1">
              <History className="w-4 h-4 text-olive" />
              <label className="text-xs font-bold uppercase tracking-wider text-sepia/70">Instituições e Bancas Alvo</label>
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => toggleBanca('Mista')}
                className={`px-4 py-2 rounded-xl border text-xs font-bold uppercase transition-all flex items-center gap-2 ${
                  bancasSelecionadas.includes('Mista') 
                  ? 'bg-olive text-white border-olive shadow-sm' 
                  : 'bg-paper text-sepia border-sepia/10 hover:border-olive/30'
                }`}
              >
                {bancasSelecionadas.includes('Mista') && <Check className="w-3 h-3" />}
                Mista
              </button>
              {EXAM_BOARDS.map(b => (
                <button
                  key={b.id}
                  type="button"
                  onClick={() => toggleBanca(b.id)}
                  className={`px-4 py-2 rounded-xl border text-xs font-bold uppercase transition-all flex items-center gap-2 ${
                    bancasSelecionadas.includes(b.id) 
                    ? 'bg-olive text-white border-olive shadow-sm' 
                    : 'bg-paper text-sepia border-sepia/10 hover:border-olive/30'
                  }`}
                >
                  {bancasSelecionadas.includes(b.id) && <Check className="w-3 h-3" />}
                  {b.nome}
                </button>
              ))}
            </div>
          </div>

          <button 
            type="submit"
            disabled={loading || !assunto}
            className="w-full p-5 bg-olive text-white rounded-2xl font-bold uppercase tracking-widest hover:bg-olive/90 transition-all shadow-lg shadow-olive/20 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Gerando {quantidade} Questões...
              </>
            ) : (
              <>
                <BookOpen className="w-5 h-5" />
                Gerar Simulado ({quantidade} Questões)
              </>
            )}
          </button>
        </form>
      </div>

      <div className="space-y-8">
        {questions.map((q, i) => (
          <QuestionCard key={i} question={q} index={i} />
        ))}
      </div>
    </div>
  );
}
