import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, TrendingUp, Info, Lightbulb, Calendar, PieChart } from 'lucide-react';
import { ExamBoard } from '../types';

interface BancaModalProps {
  banca: ExamBoard;
  onClose: () => void;
}

export default function BancaModal({ banca, onClose }: BancaModalProps) {
  const analise = banca.analise_detalhada;

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-ink/40 backdrop-blur-sm"
      onClick={onClose}
    >
      <motion.div 
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 border-b border-sepia/10 flex items-center justify-between bg-paper/30">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-olive rounded-2xl flex items-center justify-center text-white shadow-lg shadow-olive/20">
              <TrendingUp className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-2xl font-serif font-bold text-ink">{banca.nome}</h2>
              <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-sepia/40">
                <Calendar className="w-3 h-3" />
                Atualizado em: {analise?.ultima_atualizacao || 'Análise em breve'}
              </div>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 hover:bg-sepia/5 rounded-xl transition-colors text-sepia/40 hover:text-sepia"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-8 space-y-8 no-scrollbar">
          {/* Estilo e Estrutura */}
          <section className="space-y-3">
            <div className="flex items-center gap-2 text-olive">
              <Info className="w-5 h-5" />
              <h3 className="text-sm font-bold uppercase tracking-widest">Estilo e Estrutura</h3>
            </div>
            <p className="text-sepia/80 leading-relaxed bg-paper/50 p-4 rounded-2xl border border-sepia/5">
              {analise?.estrutura || banca.estilo}
            </p>
          </section>

          {/* Temas Frequentes */}
          <section className="space-y-4">
            <div className="flex items-center gap-2 text-olive">
              <PieChart className="w-5 h-5" />
              <h3 className="text-sm font-bold uppercase tracking-widest">Incidência de Temas (Média Histórica)</h3>
            </div>
            {analise?.temas_frequentes ? (
              <div className="space-y-4">
                {analise.temas_frequentes.map((item, idx) => (
                  <div key={idx} className="space-y-1.5">
                    <div className="flex justify-between text-xs font-bold text-sepia/70 px-1">
                      <span>{item.tema}</span>
                      <span>{item.porcentagem}%</span>
                    </div>
                    <div className="h-2.5 bg-paper rounded-full overflow-hidden border border-sepia/5">
                      <motion.div 
                        initial={{ width: 0 }}
                        animate={{ width: `${item.porcentagem}%` }}
                        transition={{ duration: 1, delay: 0.2 + (idx * 0.1) }}
                        className="h-full bg-olive rounded-full shadow-sm"
                      />
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-8 text-center text-sepia/30 italic bg-paper/30 rounded-2xl border border-dashed border-sepia/10">
                Dados estatísticos detalhados sendo processados para esta banca.
              </div>
            )}
          </section>

          {/* Dicas de Estudo */}
          <section className="space-y-3">
            <div className="flex items-center gap-2 text-olive">
              <Lightbulb className="w-5 h-5" />
              <h3 className="text-sm font-bold uppercase tracking-widest">Dicas de Estudo</h3>
            </div>
            <ul className="grid grid-cols-1 gap-3">
              {(analise?.dicas_estudo || [
                'Estude os editais anteriores com atenção.',
                'Pratique com provas de anos passados.',
                'Mantenha uma rotina de leitura historiográfica.'
              ]).map((dica, idx) => (
                <li key={idx} className="flex gap-3 p-4 bg-olive/5 rounded-2xl border border-olive/10 text-sepia/80 text-sm">
                  <span className="flex-shrink-0 w-6 h-6 bg-white rounded-lg border border-olive/20 flex items-center justify-center text-[10px] font-bold text-olive">
                    {idx + 1}
                  </span>
                  {dica}
                </li>
              ))}
            </ul>
          </section>

          {/* Pontuação */}
          <section className="pt-6 border-t border-sepia/5">
            <div className="bg-ink text-white p-6 rounded-2xl shadow-xl">
              <h4 className="text-[10px] font-bold uppercase tracking-[0.2em] text-white/40 mb-2">Sistema de Pontuação</h4>
              <p className="text-sm font-serif italic text-white/90">{banca.pontuacao}</p>
            </div>
          </section>
        </div>

        {/* Footer */}
        <div className="p-6 bg-paper/30 border-t border-sepia/10 text-center">
          <p className="text-[10px] font-bold text-sepia/30 uppercase tracking-widest">
            Análise baseada nos últimos 5 anos de provas oficiais
          </p>
        </div>
      </motion.div>
    </motion.div>
  );
}
