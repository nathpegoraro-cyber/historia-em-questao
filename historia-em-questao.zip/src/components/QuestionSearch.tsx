import React, { useState } from 'react';
import { searchQuestions } from '../services/gemini';
import { Question } from '../types';
import QuestionCard from './QuestionCard';
import { Search, Loader2, History } from 'lucide-react';

export default function QuestionSearch() {
  const [filtros, setFiltros] = useState({
    tema: '',
    instituicao: '',
    ano: '',
    dificuldade: '',
    tipo: ''
  });
  const [loading, setLoading] = useState(false);
  const [questions, setQuestions] = useState<Question[]>([]);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const result = await searchQuestions(filtros);
      setQuestions(result);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white border border-sepia/10 rounded-3xl p-8 shadow-sm mb-12">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-sepia/10 rounded-2xl text-sepia">
            <History className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-2xl font-serif font-bold">Recuperar Questões Reais</h2>
            <p className="text-sepia/60 text-sm">Filtre por tema, instituição, ano e dificuldade.</p>
          </div>
        </div>

        <form onSubmit={handleSearch} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-2">
              <label className="text-[10px] font-bold uppercase tracking-widest text-sepia/40 ml-1">Tema Histórico</label>
              <input 
                type="text" 
                value={filtros.tema}
                onChange={(e) => setFiltros({...filtros, tema: e.target.value})}
                placeholder="Ex: Independência do Brasil"
                className="w-full p-4 bg-paper border border-sepia/10 rounded-2xl focus:outline-none focus:ring-2 focus:ring-sepia/20 transition-all text-sm"
              />
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-bold uppercase tracking-widest text-sepia/40 ml-1">Instituição</label>
              <input 
                type="text" 
                value={filtros.instituicao}
                onChange={(e) => setFiltros({...filtros, instituicao: e.target.value})}
                placeholder="Ex: UNESP, FUVEST..."
                className="w-full p-4 bg-paper border border-sepia/10 rounded-2xl focus:outline-none focus:ring-2 focus:ring-sepia/20 transition-all text-sm"
              />
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-bold uppercase tracking-widest text-sepia/40 ml-1">Ano</label>
              <input 
                type="text" 
                value={filtros.ano}
                onChange={(e) => setFiltros({...filtros, ano: e.target.value})}
                placeholder="Ex: 2023"
                className="w-full p-4 bg-paper border border-sepia/10 rounded-2xl focus:outline-none focus:ring-2 focus:ring-sepia/20 transition-all text-sm"
              />
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-bold uppercase tracking-widest text-sepia/40 ml-1">Dificuldade</label>
              <div className="flex gap-2">
                {['fácil', 'médio', 'difícil'].map(nivel => (
                  <button
                    key={nivel}
                    type="button"
                    onClick={() => setFiltros({...filtros, dificuldade: filtros.dificuldade === nivel ? '' : nivel})}
                    className={`flex-1 py-3 rounded-xl border text-[10px] font-bold uppercase transition-all ${
                      filtros.dificuldade === nivel
                      ? 'bg-sepia text-white border-sepia shadow-sm'
                      : 'bg-paper text-sepia border-sepia/10 hover:border-sepia/30'
                    }`}
                  >
                    {nivel}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-bold uppercase tracking-widest text-sepia/40 ml-1">Tipo</label>
              <div className="flex gap-2">
                {['objetiva', 'discursiva'].map(t => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => setFiltros({...filtros, tipo: filtros.tipo === t ? '' : t})}
                    className={`flex-1 py-3 rounded-xl border text-[10px] font-bold uppercase transition-all ${
                      filtros.tipo === t
                      ? 'bg-sepia text-white border-sepia shadow-sm'
                      : 'bg-paper text-sepia border-sepia/10 hover:border-sepia/30'
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <button 
            type="submit"
            disabled={loading}
            className="w-full p-5 bg-sepia text-white rounded-2xl font-bold uppercase tracking-widest hover:bg-sepia/90 transition-all shadow-lg shadow-sepia/20 disabled:opacity-50 flex items-center justify-center gap-3"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <><Search className="w-5 h-5" /> Buscar Questões</>}
          </button>
        </form>
      </div>

      <div className="space-y-8">
        {questions.map((q, i) => (
          <QuestionCard key={i} question={q} index={i} />
        ))}
        {questions.length === 0 && !loading && (
          <div className="text-center py-12 text-sepia/30 italic">
            Nenhuma questão encontrada. Tente ajustar os filtros.
          </div>
        )}
      </div>
    </div>
  );
}
