import React, { useState } from 'react';
import { Question } from '../types';
import { ChevronDown, ChevronUp, CheckCircle2, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface QuestionCardProps {
  question: Question;
  index: number;
}

const QuestionCard: React.FC<QuestionCardProps> = ({ question, index }) => {
  const [showComment, setShowComment] = useState(false);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);

  const isCorrect = (option: string) => {
    const letter = option.trim().charAt(0).toUpperCase();
    return letter === question.gabarito.toUpperCase();
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1 }}
      className="bg-white border border-sepia/10 rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow"
    >
      <div className="flex justify-between items-start mb-4">
        <div className="flex flex-col gap-1">
          <span className="text-xs font-mono uppercase tracking-widest text-sepia/60">
            Questão {index + 1} — {question.banca_simulada || question.vestibular_original}
          </span>
          <div className="flex gap-2">
            <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
              question.tipo === 'objetiva' ? 'bg-blue-50 text-blue-600' : 'bg-purple-50 text-purple-600'
            }`}>
              {question.tipo}
            </span>
            <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-wider ${
              question.dificuldade === 'fácil' ? 'bg-green-50 text-green-600' : 
              question.dificuldade === 'médio' ? 'bg-yellow-50 text-yellow-600' : 'bg-red-50 text-red-600'
            }`}>
              {question.dificuldade}
            </span>
          </div>
        </div>
        {selectedOption && question.tipo === 'objetiva' && (
          <div className={`flex items-center gap-1 text-sm font-medium ${isCorrect(selectedOption) ? 'text-green-600' : 'text-red-600'}`}>
            <CheckCircle2 className="w-4 h-4" />
            {isCorrect(selectedOption) ? 'Correto' : 'Incorreto'}
          </div>
        )}
      </div>

      <div className="mb-6 italic text-sm text-sepia/80 border-l-2 border-sepia/20 pl-4 py-1 leading-relaxed">
        {question.texto_apoio}
      </div>

      <h3 className="text-lg font-medium mb-6 leading-snug">
        {question.enunciado}
      </h3>

      {question.tipo === 'objetiva' ? (
        <div className="space-y-3 mb-6">
          {question.alternativas.map((alt, i) => {
            const letter = alt.trim().charAt(0).toUpperCase();
            const isSelected = selectedOption === alt;
            const isActuallyCorrect = letter === question.gabarito.toUpperCase();
            
            let bgColor = "bg-paper/50 hover:bg-paper";
            let borderColor = "border-sepia/10";
            
            if (selectedOption) {
              if (isActuallyCorrect) {
                bgColor = "bg-green-50";
                borderColor = "border-green-200";
              } else if (isSelected) {
                bgColor = "bg-red-50";
                borderColor = "border-red-200";
              }
            }

            return (
              <button
                key={i}
                onClick={() => !selectedOption && setSelectedOption(alt)}
                disabled={!!selectedOption}
                className={`w-full text-left p-4 rounded-xl border transition-all ${bgColor} ${borderColor} ${!selectedOption ? 'cursor-pointer' : 'cursor-default'}`}
              >
                <span className="font-serif font-bold mr-2">{letter}</span>
                {alt.substring(alt.indexOf(')') + 1).trim() || alt.substring(2).trim()}
              </button>
            );
          })}
        </div>
      ) : (
        <div className="mb-6 p-4 bg-paper/30 border border-dashed border-sepia/20 rounded-xl">
          <p className="text-xs font-bold uppercase tracking-widest text-sepia/40 mb-2">Espaço para Resposta Discursiva</p>
          <textarea 
            placeholder="Escreva sua resposta aqui para treinar..."
            className="w-full bg-transparent border-none focus:ring-0 text-sm min-h-[100px] resize-none"
          />
        </div>
      )}

      <div className="border-t border-sepia/5 pt-4">
        <button 
          onClick={() => setShowComment(!showComment)}
          className="flex items-center gap-2 text-sm font-medium text-sepia hover:text-olive transition-colors"
        >
          <Info className="w-4 h-4" />
          {showComment ? 'Ocultar Resposta' : question.tipo === 'objetiva' ? 'Ver Comentário e Gabarito' : 'Ver Padrão de Resposta'}
          {showComment ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        <AnimatePresence>
          {showComment && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="overflow-hidden"
            >
              <div className="mt-4 p-4 bg-paper rounded-xl text-sm leading-relaxed text-sepia/90">
                <p className="font-bold mb-2">{question.tipo === 'objetiva' ? 'Gabarito:' : 'Padrão de Resposta:'} {question.gabarito}</p>
                <p>{question.comentario}</p>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
};

export default QuestionCard;
