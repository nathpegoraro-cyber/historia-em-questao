import React from 'react';
import { HISTORIOGRAPHY } from '../constants';
import { motion } from 'motion/react';
import { Library, Book } from 'lucide-react';

export default function HistoriographyInfo() {
  return (
    <div className="max-w-5xl mx-auto space-y-12">
      <header className="text-center space-y-4">
        <h2 className="text-4xl font-serif font-bold text-sepia">Biblioteca de Referência</h2>
        <p className="text-sepia/60 max-w-2xl mx-auto">
          O motor de questões utiliza exclusivamente fontes de historiadores de reconhecido valor científico.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {HISTORIOGRAPHY.map((item, i) => (
          <motion.div 
            key={item.periodo}
            initial={{ opacity: 0, x: i % 2 === 0 ? -20 : 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-white border border-sepia/10 rounded-3xl p-8 shadow-sm"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="p-3 bg-sepia/5 text-sepia rounded-2xl">
                <Library className="w-6 h-6" />
              </div>
              <h3 className="text-2xl font-serif font-bold">{item.periodo}</h3>
            </div>

            <div className="space-y-6">
              {item.leituras.map((leitura, j) => (
                <div key={j} className="flex gap-4 group">
                  <div className="mt-1">
                    <Book className="w-4 h-4 text-olive/40 group-hover:text-olive transition-colors" />
                  </div>
                  <div>
                    <p className="text-xs font-bold uppercase tracking-wider text-sepia/40 mb-1">{leitura.autor}</p>
                    <p className="text-lg font-serif italic text-sepia/90 leading-tight">{leitura.titulo}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}
