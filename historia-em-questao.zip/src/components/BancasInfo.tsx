import React, { useState } from 'react';
import { EXAM_BOARDS } from '../constants';
import { motion, AnimatePresence } from 'motion/react';
import { Award, Target, ChevronRight } from 'lucide-react';
import { ExamBoard } from '../types';
import BancaModal from './BancaModal';

export default function BancasInfo() {
  const [selectedBanca, setSelectedBanca] = useState<ExamBoard | null>(null);

  return (
    <div className="max-w-5xl mx-auto space-y-12">
      <header className="text-center space-y-4">
        <h2 className="text-4xl font-serif font-bold text-sepia">Identidades das Bancas</h2>
        <p className="text-sepia/60 max-w-2xl mx-auto">
          Cada vestibular possui uma "personalidade" única. Clique em uma banca para ver a análise detalhada de temas e estrutura.
        </p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {EXAM_BOARDS.map((banca, i) => (
          <motion.div 
            key={banca.id}
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.05 }}
            onClick={() => setSelectedBanca(banca)}
            className="bg-white border border-sepia/10 rounded-3xl p-6 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all group cursor-pointer relative overflow-hidden"
          >
            <div className="absolute top-0 right-0 p-4 opacity-0 group-hover:opacity-100 transition-opacity">
              <ChevronRight className="w-5 h-5 text-olive" />
            </div>

            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-olive/10 text-olive rounded-xl group-hover:bg-olive group-hover:text-white transition-colors">
                <Award className="w-5 h-5" />
              </div>
              <h3 className="text-xl font-serif font-bold">{banca.nome}</h3>
            </div>
            
            <div className="space-y-4">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-sepia/40 block mb-1">Estilo e Estrutura</span>
                <p className="text-sm text-sepia/80 leading-relaxed line-clamp-3">{banca.estilo}</p>
              </div>
              
              <div className="pt-4 border-t border-sepia/5">
                <div className="flex items-center gap-2 text-olive mb-1">
                  <Target className="w-4 h-4" />
                  <span className="text-[10px] font-bold uppercase tracking-widest">Método de Pontuação</span>
                </div>
                <p className="text-xs text-sepia/60 italic">{banca.pontuacao}</p>
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-sepia/5 flex justify-center">
              <span className="text-[10px] font-bold uppercase tracking-widest text-olive group-hover:underline">Ver análise detalhada</span>
            </div>
          </motion.div>
        ))}
      </div>

      <AnimatePresence>
        {selectedBanca && (
          <BancaModal 
            banca={selectedBanca} 
            onClose={() => setSelectedBanca(null)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}
